# Grcan’s CPTS Workspace — Offline

Extract this entire folder and open index.html in a modern browser. No installation or server is required. Built 2026-09-20, with 274 published reference pages, the search index, 67 practice boxes, and all ten AD workflows.

Commands opens the same quick tool sheets and saved notebook examples as the website. Continue studying opens your saved box notebook and revision queue. Find something searches notes and commands. Practice a box opens the existing prerequisite filters and IppSec references. Videos and external links need internet access.

Hosted and offline copies have separate browser storage. In My workspace, choose Backup & offline, download JSON, and import that file in the other copy. Import adds lab copies; existing practice records win. Keep the folder in one stable location and make regular JSON backups, especially before clearing browser data or moving to a new device. Evidence files are not included in browser backups; keep those separately.

Network requests and remote scripts are blocked by this offline page’s Content Security Policy. Links only navigate when you choose them. Personal records stay in this browser; the distributed ZIP contains only public vault content, never your browser notes. Reference pages are rendered as readable text, tables, code and images; interactive Mintlify decorations are simplified.

For exam use, follow your own current HTB exam instructions: https://help.hackthebox.com/en/articles/12741732-academy-certifications . This is a reference and personal notebook, with no AI solver or report generation.
